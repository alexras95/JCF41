package uc_w1_compare;

import java.util.Comparator;

public class StringlengthComparator implements Comparator<String> {

	@Override
	public int compare(String s1, String s2) {
		int cmp = s1.length() - s2.length();
		if (cmp != 0)
			return cmp;
		else
			return s1.compareTo(s2);
	}

}
