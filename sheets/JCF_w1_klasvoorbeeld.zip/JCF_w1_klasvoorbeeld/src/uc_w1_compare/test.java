package uc_w1_compare;

import java.util.*;

public class test {

    /**
     * @param args
     */
    public static void main(String[] args) {
        // gebruik interfaces voor gedrag, implementatie voor performance.
        List<String> list = new LinkedList<>(); //new ArrayList<String>();


        list.add("een");
        list.add("twee");
        list.add("drie");
        list.add("elf");
        list.add("x");
        list.add("vijfje");
        list.add("een erglange string");

        // zie Collections api 
        // sort alfabetisch (gebruik comparable gedrag van String, zie String)
        Collections.sort(list);
        System.out.println("met sortering via natuurlijk ordening van de elementen (comparare)");
        // impliciete iterator
        for (String l : list) {
            System.out.println(l);
        }



        // sorteer mbv expliciete comparator
        Collections.sort(list, new StringlengthComparator());
       System.out.println("met sortering via comparator");
        // impliciete iterator
		for(String l : list){System.out.println(l);}

        // print all elements using get method of List
//		for(int i = 0; i<list.size();i++){
//			String tmp = list.get(i);
//			System.out.println(tmp);
//		}

        // impliciete iterator
//		for(String l : list){System.out.println(l);}


        // list all methods using general Iterator of List (casting to String needed)
//		Iterator iter = list.iterator();
//		while(iter.hasNext()){
//			String tmp = (String)iter.next();
//			System.out.println(tmp);
//		}

        // list all methods using generic iterator. (no casting needed)
//		Iterator<String> iter2 = list.iterator();
//		while(iter2.hasNext()){
//			String tmp = iter2.next();
//			System.out.println(tmp);
//		}

    }
}
