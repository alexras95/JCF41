/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jcf41.uitvoeringscomplexiteit;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

/**
 *
 * @author 874529
 */
public class MyCollection {
   
    protected Collection names;
    
    public MyCollection(Collection init) {
        names = init;
    }
    
    public void add(String name) {
        names.add(name);
    }
    
    public boolean contains(String name) {
        return names.contains(name);
    }
    
    public ArrayList getGesorteerd() {
        ArrayList al = new ArrayList<String>(names);
        
        Collections.sort(al);
        
        return al;
    }
    
}
