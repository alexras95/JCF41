/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jcf41.uitvoeringscomplexiteit;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author 874529
 */
public class ArrayListHashset {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        MyCollection c = new MyCollection(new ArrayList());
        
        int naar_oneindig = 10000;
        
       long nb_seconden = 0;
        
       long start = System.currentTimeMillis();
        Random r = new Random();
        
       for (int i = 0; i < naar_oneindig; i++) {
           String name = ""+r.nextInt();
           if(!c.contains(name)) {
                c.add(name);
                c.getGesorteerd();
           }
           
       }
       
        
        nb_seconden = (System.currentTimeMillis() - start)/1000;
        
        visualise(nb_seconden);
    }

    private static void visualise(long nb_seconden) {
         System.out.println("Time needed: "+nb_seconden);
        for (int i = 0; i < nb_seconden; i++) {
            System.out.print("|");
        }
        
        System.out.println();
    }
    
}
