package stack;
/**
 * Stack interface.  maakt nog gebruik van Objecten ipv generic typen.
 * @author erik
 *
 */
public interface Stack_Obsolete {
	
	/**
	 * Add Object to stack 
	 * @param o object to be added
	 */
	public void push(Object o);
	
	/**
	 * Throw last added object from stack. If no object is present, method does nothing.
	 */
	public void pop();
	
	/**
	 * Show last added Object from stack. If no object is present, return null.
	 * @return Object on top of stack, or null if stack is empty
	 */
	public Object Peek();
}