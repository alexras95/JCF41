package stack;

import java.util.LinkedList;
import java.util.Queue;

/**
 * Linked List implementation of IStack.
 * @author erik
 */
public class LinkedListStack<E> implements IStack<E>{
    private Queue list = new LinkedList();

    @Override
    public void push(E o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void pop() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public E Peek() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
}
