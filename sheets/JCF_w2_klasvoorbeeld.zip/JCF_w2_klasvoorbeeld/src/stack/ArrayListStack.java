/**
 * 
 */
package stack;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @author erik
 *
 */
public class ArrayListStack<E> implements IStack<E> {
	private List<E> list;
	
	public ArrayListStack(){
		this.list = new ArrayList<E>();
                // wat zijn de gevolgen in functionaliteit, 
                // snelheid en geheugengebruik als we hier 
                // LinkedList<E>() gebruiken?
                //
	}

        /**
         * hier zit nog een schoonheidsfout in
         * @return
         */
	@Override
	public E Peek() {
		return this.list.get(this.list.size()-1);
	}

        /**
         * hier zit nog een schoonheidsfout in, wat?
         */
	@Override
	public void pop() {
		this.list.remove(this.list.size()-1);
	}

	@Override
	public void push(E o) {
		this.list.add(o);
	}

}
