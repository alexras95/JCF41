package stack;
/**
 * Generic implementation of IStack. If class implements
 * IStack<E>, than it inherits the generic methods.
 * If a class inherits GenericStack, than it gets the non-generic methods
 * 
 * @author erik
 *
 * @param <E> the object types on this stack
 */
public interface IStack<E>{
	/**
	 * Add object of type E to stack
	 * @param o object to be added
	 */
	public void push(E o);
	
	
	/**
	 * Throw last added object from stack. If no object is present, method does nothing.
	 */
	public void pop();
	
	/**
	 * Show last added Object from stack. If no object is present, return null.
	 * @return Object on top of stack, or null if stack is empty
	 */
	public E Peek();

}
